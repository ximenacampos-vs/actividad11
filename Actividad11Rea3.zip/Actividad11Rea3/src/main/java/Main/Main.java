/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Main;

import Modelo.*;
import Controlador.*;
import Vista.Vista;

public class Main {
    public static void main(String[] args) {        
       
        Modelo modelo = new Modelo();
        Vista vista = new Vista();
        Controlador controlador = new Controlador(modelo, vista);
        
        controlador.iniciarVista();
        
    } 
}
